<?php
/*
header.php 是自訂的檔案，給前台所有檔案用的。
若有一些東西是將前台每個檔案都要引入，那麼都可以放在這裡。
*/

//一定要引入的XOOPS網站設定檔（必要），否則模組不會運作。
include_once "../../mainfile.php";
//引入自訂的共同函數檔（非必要）
include_once "function.php";

//判斷是否對該模組有管理權限，若有管理權 $isAdmin=true;
$isAdmin=false;
if ($xoopsUser) {
  $module_id = $xoopsModule->getVar('mid');
  $isAdmin=$xoopsUser->isAdmin($module_id);
}


/*------------------ 設定此模組的前台選單（[中文] 裡面的中文會變成使用者看到的選項） ------------------*/

//回模組首頁
$interface_menu[_TAD_TO_MOD]="index.php";

//僅管理員有權限看到的選項
if($isAdmin){
  //後台模組管理
  $interface_menu[_TAD_TO_ADMIN]="admin/main.php";
}
?>