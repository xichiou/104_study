<?php
/*
function.php 是用來放置共同函數的檔案
若有一些函數是前後台檔案會用到的，那麼可以將該函數放在這裡。
*/


//先確認 TadTools 是否存在
if(!file_exists(XOOPS_ROOT_PATH."/modules/tadtools/tad_function.php")){
  //若不存在提示安裝
  redirect_header("http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50",3, _TAD_NEED_TADTOOLS);
}
//引入TadTools的函式庫，若沒載入此行，所有 tadtools 相關功能將無法使用
include_once XOOPS_ROOT_PATH."/modules/tadtools/tad_function.php";

//新聞列表
function news_list(){
	global $xoopsDB ,$xoopsTpl,$xoopsUser;

	//日期從大排到小，列出所有新聞
	$sql="select * from ".$xoopsDB->prefix("school_news")." order by `post_date` desc";

	//getPageBar($原sql語法, 每頁顯示幾筆資料, 最多顯示幾個頁數選項);
	$PageBar=getPageBar($sql,3,$page_num);
	$bar=$PageBar['bar'];
	$sql=$PageBar['sql'];
	$total=$PageBar['total'];

	//送到資料庫執行
	$result=$xoopsDB->query($sql) or die(mysql_error());

	//$all_data 代表所有新聞，預設為空值
	$all_data="";

	//從第0筆資料開始抓取
	$i=0;

	//開始陸續抓回資料，一次僅能抓一筆，故用 while 才能抓出所有資料
	while($all=$xoopsDB->fetchArray($result)){

		//抓取其中使用者編號
		$uid=$all['uid'];

		//根據uid轉換成姓名
		$uid_name=$xoopsUser->getVar('name');
		if(empty($uid_name))$uid_name=XoopsUser::getUnameFromId($uid,0);

		//將姓名塞進資料陣列中
		$all['uid_name']=$uid_name;

		//依序的把抓回的資料塞入$all_data中
		$all_data[$i]=$all;

		//資料筆數遞增
		$i++;
	}

	//var_dump($all_data);die();

	//將所有新聞內容送到樣板中
	$xoopsTpl->assign("all_data" , $all_data);

	//將換頁工具列送到樣板中
	$xoopsTpl->assign("bar" , $bar);


}




?>