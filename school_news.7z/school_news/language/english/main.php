<?php
//前台語系
//define("_MD_XXX","");

?>