<?php
//載入共同的語系（請勿移除，部份Tadtools下的程式會用到）
include_once XOOPS_ROOT_PATH."/modules/tadtools/language/{$xoopsConfig['language']}/modinfo_common.php";

//設定檔語系（請移除以下語系設定前的註解）
//define('_MI_XXX' , '');
?>