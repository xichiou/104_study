<?php
//區塊語系
define("_MB_XXX","");

?>