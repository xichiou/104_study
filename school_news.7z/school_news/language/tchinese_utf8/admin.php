<?php
//載入共同的語系
include_once "../../tadtools/language/{$xoopsConfig['language']}/admin_common.php";
//提示載入TadTools
define("_TAD_NEED_TADTOOLS"," 需要 tadtools 模組，可至<a href='http://www.tad0616.net/modules/tad_uploader/index.php?of_cat_sn=50' target='_blank'>Tad教材網</a>下載。");
//define("_MA_XXX","");

?>